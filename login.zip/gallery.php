<?php
// Database connection details
$servername = 'localhost';
$username = "root";
$password = "";
$database = "adolph.t database";

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve images and descriptions in descending order
$sql = "SELECT image_path, image_description FROM image_gallery ORDER BY image_id DESC";
$result = $conn->query($sql);

// Generate HTML for displaying images and descriptions
$html = '';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imagePath = $row['image_path'];
        $imageDescription = $row['image_description'];

        // Generate HTML for each image and description
        $html .= '<div class="image-container" style="border:1px solid black;margin:20px;border-radius:10px">';
        $html .= '<img src="' . $imagePath . '" alt="' . $imageDescription . '" style="height: 270px; width: 500px;">';
        $html .= '<p  style="margin-top:20px">Description: ' . $imageDescription . '</p>';
        $html .= '</div>';
    }
} else {
    $html = '<p>No images found.</p>';
}

// Close the database connection
$conn->close();
?>




<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/logo.png">
    <title>Gallery</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="index.css">
   <style>
.nav-container {
  position: relative;
  display: inline-block;
}

#dropdown {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: #2a0134;
  padding: 10px 0;
  width: 300px;
  text-align: center;
}

#dropdown a:hover {
  background-color: grey;
}

#dropdown a {
  border-bottom: 1px solid white;
  list-style-type: none;
}

#dropdown a {
  color: white;
  display: block;
  font-weight: lighter;
  padding-bottom: 10px;
}

#hoverer {
  cursor: pointer;
}

/* Show the dropdown when either the "Services" link or the dropdown itself is hovered */
#hoverer:hover + #dropdown,
#dropdown:hover {
  display: block;
}

   </style>
</head>
<body>
    <header class="text-gray-600 body-font w-full z-50">
        <div class="title-font font-medium text-gray-900" id="custom-container" style="height: 80px;">
          <div style="text-align: left;">
            <img src="images/logo.png" width="150px" style="margin-left: 4%;" />
            <h1 class="text-[purple] cursor-pointer" style="font-size: 13px; padding-left: 20px;">Adolph T. Resources Nigeria Limited</h1>
          </div>
      
          <div id="upul">
            <p class="text-gray-900 font-bold cursor-pointer">Email: adolph.t.resources@gmail.com</p>
            <p class="text-gray-900 font-bold cursor-pointer">Tel1: +234 (0) 803 579 4886<br /> Tel2: +234 (0) 703 486 7802</p>
          </div>
        </div>
      
        <div id="header" >
          <div style="text-align: left;">
            <img src="images/logo.png" width="80px" style="margin-left: 10%;" />
            <h1 class="text-[purple] cursor-pointer" style="font-size: 13px; padding-left: 20px;">Adolph T. Resources Nigeria Limited</h1>
          </div>
          <span id="span" onclick="toggleMenu()">&#9776;</span>
        </div>
      
        <div>
        <ul id="ul">
                <li><a class="hover:text-[#fe5000] cursor-pointer text-[#2a0134]" href="index.html">Home</a></li>
                <li><a class="hover:text-[#fe5000] cursor-pointer text-[#2a0134]" href="about.html">About</a></li>
                <li class="dropdown-item">
                  Services
                  <ul class="sub-menu">
                    <li><a id="hovs" href='scafolding.html'>Scaffolding</a></li>
                    <li><a id="hovs" href='training.html'>Scaffolding training</a></li>
                    <li><a id="hovs" href='safehouse.html'>Safehouse pressurized habitat</a></li>
                    <li><a id="hovs" href='maintanance.html'>Maintenance and Construction Support</a></li>
                    <li><a id="hovs" href='renting.html'>Renting of equipment and procurement</a></li>
                  </ul>
                </li>
                <script>function toggleSubMenu() {
                  const subMenu = document.querySelector('.sub-menu');
                  subMenu.classList.toggle('open');
                }
                
                function handleSubMenuItemClick() {
                  closeMenu(); // Call closeMenu when a submenu item is clicked
                }
                
                document.querySelector('.dropdown-item').addEventListener('click', toggleSubMenu);
                const subMenuLinks = document.querySelectorAll('.sub-menu a');
                
                subMenuLinks.forEach((link) => {
                  link.addEventListener('click', handleSubMenuItemClick);
                });
                </script>
                <li><a class="hover:text-[#fe5000] cursor-pointer text-[#2a0134]" href="gallery.php">Gallery</a></li>
                <li><a class="hover:text-[#fe5000] cursor-pointer text-[#2a0134]" href="updates.php">Updates</a></li>
                <li><a class="hover:text-[#fe5000] cursor-pointer text-[#2a0134]" href="certificate-verification.html" onclick="closeMenu()">Certificate verification</a></li>
                <li>
                    <a href="contact.html">
                        <button class="items-center bg-[#FF595A] border-0 py-2 px-6 focus:outline-none 
                        hover:bg-[#fe5000] rounded text-[#001233] mt-4 md:mt-0 font-bold">Contact us</button>
                    </a>
                </li>
            </ul>
        </div>
      </header>

      <!-- nav -->

      <nav id="navs" class="md:ml-auto items-center text-base justify-center text-[#ffffffd4] font-bold" style="text-align: center; padding: 8px;">
        <a class="mr-5 cursor-pointer" id="hover" href="index.html">Home</a>
        <a class="mr-5 cursor-pointer" id="hover" href="about.html">About</a>
       
        <div class="nav-container">
          <a class="mr-5 cursor-pointer" id="hoverer" onmouseenter="openDropdown()" onmouseleave="closeDropdown()">Services</a>
          <ul id="dropdown">
            <a href="scafolding.html">Scaffolding</a>
            <a href="training.html">Scaffolding training</a>
            <a href="safehouse.html">Safehouse pressurized habitat</a>
            <a href="maintanance.html">Maintenance and Construction Support</a>
            <a href="renting.html">Renting of equipment and procurement.</a>
          </ul>
        </div>
        
        
        <a class="mr-5 cursor-pointer" id="hover" href="gallery.php">Gallery</a>
        <a class="mr-5 cursor-pointer" id="hover" href="updates.php">Updates</a>
        <a class="mr-5 cursor-pointer" id="hover" href="certificate-verification.html">Certificate verification</a>
      
        <a href="contact.html">
          <button class="bg-[#FF595A] border-0 py-2 px-6 focus:outline-none hover:text-[white] rounded text-[#001233] font-bold">Contact us</button>
        </a>
      </nav>
      

<!-- content -->
<div class="image-gallery" style="display: flex; flex-direction: row; flex-wrap: wrap;">
    <?php echo $html; ?>
</div>










  









<!-- footer -->
<footer class="text-gray-600 body-font bg-[#2a0134]">
    <div class="container px-5 py-8 mx-auto flex items-center sm:flex-row flex-col">
      <a class="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
        <span class="ml-3 text-xl text-[#ffffff]">Adolph T. Resources</span> 
      </a>
      <p class="text-sm text-[#ffffff] sm:ml-4 sm:pl-4 sm:border-l-2 sm:border-gray-200 sm:py-2 sm:mt-0 mt-4">
        adolph.t.resources@gmail.com 
        <span style="border-right: 2px solid white; height: 70px;"></span>
        <a class="text-#ffffff ml-1" rel="noopener noreferrer" target="_blank"></a> 
        Tel: +234 (0) 803 579 4886, +234 (0) 703 486 7802
      </p>
      <span class="inline-flex sm:ml-auto sm:mt-0 mt-4 justify-center sm:justify-start">
        <a class="text-gray-500">
          <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
            <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path>
          </svg>
        </a>
        <a class="ml-3 text-gray-500">
          <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
            <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path>
          </svg>
        </a>
        <a class="ml-3 text-gray-500">
          <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-5 h-5" viewBox="0 0 24 24">
            <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
            <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01"></path>
          </svg>
        </a>
        <a class="ml-3 text-gray-500">
          <svg fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="0" class="w-5 h-5" viewBox="0 0 24 24">
            <path stroke="none" d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"></path>
            <circle cx="4" cy="4" r="2" stroke="none"></circle>
          </svg>
        </a>
      </span>
    </div>
  </footer>
  <script>
let isMenuOpen = false;

const toggleMenu = () => {
    const menu = document.getElementById("ul");
    
    if (!isMenuOpen) {
        menu.style.height = "auto";
        isMenuOpen = true;
    } else {
        menu.style.height = "0px";
        isMenuOpen = false;
    }
};

const closeMenu = () => {
    const menu = document.getElementById("ul");
    menu.style.height = "0px";
    isMenuOpen = false;
};
</script>

    <script src="index.js"></script>
</body>
</html>