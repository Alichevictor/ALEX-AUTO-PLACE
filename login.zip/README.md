# adolf.t.resources
